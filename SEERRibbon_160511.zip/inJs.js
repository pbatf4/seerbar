// This script simply includes the javascript file specified in scriptUrl
;(function(inJsBHOAPI) {
  // The BHO has trouble detecting page refresh events. The workaround causes this script to be injected twice so we check if it has already happened or not.
  if (!window.inJsBHOScriptLoaded) {
    if(console && console.log) console.log('loading BHO');

    var head = document.getElementsByTagName('head')[0];

    // Set this to the URL of whatever script you wish to load
    var baseUrl = 'https://thelonelyghost.github.io/maximo_seer/dist/',
      scriptUrl = baseUrl + 'package-main.js',
      styleUrl = baseUrl + 'package-main.css';

    var script = document.createElement('script'),
      link = document.createElement('link');

    script.setAttribute('type', 'text/javascript');
    script.setAttribute('src', scriptUrl);

    link.setAttribute('rel', 'stylesheet');
    link.setAttribute('href', styleUrl);

    head.appendChild(link);
    head.appendChild(script);

    window.inJsBHOScriptLoaded = true;
  }
})(window.inJsBHOAPI = window.inJsBHOAPI || {});
